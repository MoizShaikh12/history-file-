from modules.utils import normalize_value


def _normalized_allowed(values):
    return {normalize_value(v) for v in values}


def add_ot_filter_column(
    df,
    job_family_group_allowed,
    job_family_allowed,
    job_profile_allowed,
    ot_filter_column="OT Filter",
):
    required = ["Job Family Group", "Job Family", "Job Profile Description"]

    for col in required:
        if col not in df.columns:
            raise KeyError(f"Required OT filter source column '{col}' not found in output.")

    output_df = df.copy()

    jfg_allowed = _normalized_allowed(job_family_group_allowed)
    jf_allowed = _normalized_allowed(job_family_allowed)
    jp_allowed = _normalized_allowed(job_profile_allowed)

    ot_match_mask = (
        output_df["Job Family Group"].apply(normalize_value).isin(jfg_allowed)
        & output_df["Job Family"].apply(normalize_value).isin(jf_allowed)
        & output_df["Job Profile Description"].apply(normalize_value).isin(jp_allowed)
    )

    output_df[ot_filter_column] = "No"
    output_df.loc[ot_match_mask, ot_filter_column] = "Yes"

    cols = [col for col in output_df.columns if col != ot_filter_column]
    output_df = output_df[cols + [ot_filter_column]]

    stats = {
        "rows_before_ot_column": int(len(df)),
        "rows_after_ot_column": int(len(output_df)),
        "ot_filter_yes_rows": int(ot_match_mask.sum()),
        "ot_filter_no_rows": int((~ot_match_mask).sum()),
        "rows_removed_by_ot_filter": 0,
    }

    return output_df, stats
