import re
from html import unescape
import pandas as pd


def normalize_header(value):
    if value is None:
        return ""
    value = unescape(str(value)).replace("\r", "").replace("\n", " ")
    value = re.sub(r"\s+", " ", value.strip())
    return value.casefold()


def normalize_value(value):
    if pd.isna(value):
        return ""
    value = unescape(str(value)).replace("\r", "").replace("\n", " ")
    value = re.sub(r"\s+", " ", value.strip())
    return value.casefold()


def normalize_email(value):
    if pd.isna(value):
        return ""
    return str(value).strip().casefold()


def normalize_id(value):
    if pd.isna(value):
        return ""
    text = str(value).strip()
    if text.endswith(".0"):
        text = text[:-2]
    text = re.sub(r"\s+", "", text)
    return text.casefold()


def resolve_column(df, wanted_column):
    lookup = {}
    for col in df.columns:
        norm = normalize_header(col)
        if norm and norm not in lookup:
            lookup[norm] = col
    return lookup.get(normalize_header(wanted_column))


def extract_emails_from_text(value):
    if pd.isna(value):
        return []
    text = str(value)
    return re.findall(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}", text)
