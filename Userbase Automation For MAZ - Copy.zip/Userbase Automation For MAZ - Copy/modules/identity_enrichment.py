import pandas as pd

from modules.utils import resolve_column, normalize_email


def _make_first_value_map(df, key_column, value_column):
    if key_column not in df.columns:
        raise KeyError(f"Mapping key column '{key_column}' not found.")
    if value_column not in df.columns:
        raise KeyError(f"Mapping value column '{value_column}' not found.")

    work = df[[key_column, value_column]].copy()
    work["__email_key__"] = work[key_column].apply(normalize_email)
    work = work.loc[work["__email_key__"].ne("")]

    value_map = {}

    for _, row in work.iterrows():
        email_key = row["__email_key__"]
        value = row[value_column]

        if email_key not in value_map and not pd.isna(value) and str(value).strip() != "":
            value_map[email_key] = value

    return value_map


def _make_email_set(df, key_column):
    if key_column not in df.columns:
        raise KeyError(f"Lookup email column '{key_column}' not found.")

    return set(df[key_column].apply(normalize_email).loc[lambda s: s.ne("")])


def _standardize_reference_columns(df, required_columns):
    output = df.copy()
    rename_map = {}

    for wanted in required_columns:
        actual = resolve_column(output, wanted)
        if actual is not None and actual != wanted:
            rename_map[actual] = wanted

    if rename_map:
        output = output.rename(columns=rename_map)

    return output


def enrich_with_identity_sources(
    output_df,
    employee_email_column,
    saviynt_df,
    o365_df,
    aurora_df,
    bsc_df,
    saviynt_output_column="SSOUPN as per Saviynt",
    o365_output_column="SSOUPN as per AD (O365)",
    aurora_output_column="Aurora Users",
    bsc_output_column="BSC (Yes/No)",
):
    if employee_email_column not in output_df.columns:
        raise KeyError(f"Employee email column '{employee_email_column}' not found in output dataframe.")

    final_df = output_df.copy()
    output_email_key = final_df[employee_email_column].apply(normalize_email)

    saviynt_df = _standardize_reference_columns(saviynt_df, ["User Email", "SSO UPN"])
    o365_df = _standardize_reference_columns(o365_df, ["Mail", "UserPrincipalName"])
    aurora_df = _standardize_reference_columns(aurora_df, ["E-MAIL"])
    bsc_df = _standardize_reference_columns(bsc_df, ["Email - Primary Work"])

    saviynt_map = _make_first_value_map(saviynt_df, "User Email", "SSO UPN")
    o365_map = _make_first_value_map(o365_df, "Mail", "UserPrincipalName")
    aurora_email_set = _make_email_set(aurora_df, "E-MAIL")
    bsc_email_set = _make_email_set(bsc_df, "Email - Primary Work")

    final_df[saviynt_output_column] = output_email_key.map(saviynt_map).fillna("")
    final_df[o365_output_column] = output_email_key.map(o365_map).fillna("")
    final_df[aurora_output_column] = output_email_key.isin(aurora_email_set).map({True: "yes", False: "no"})
    final_df[bsc_output_column] = output_email_key.isin(bsc_email_set).map({True: "yes", False: "no"})

    new_cols = [
        saviynt_output_column,
        o365_output_column,
        aurora_output_column,
        bsc_output_column,
    ]
    existing_cols = [col for col in final_df.columns if col not in new_cols]
    final_df = final_df[existing_cols + new_cols]

    stats = {
        "rows_before_identity_enrichment": int(len(output_df)),
        "rows_after_identity_enrichment": int(len(final_df)),
        "saviynt_reference_rows": int(len(saviynt_df)),
        "o365_reference_rows": int(len(o365_df)),
        "aurora_reference_rows": int(len(aurora_df)),
        "bsc_reference_rows": int(len(bsc_df)),
        "saviynt_sso_upn_matched_rows": int(final_df[saviynt_output_column].astype(str).str.strip().ne("").sum()),
        "o365_upn_matched_rows": int(final_df[o365_output_column].astype(str).str.strip().ne("").sum()),
        "aurora_yes_rows": int(final_df[aurora_output_column].eq("yes").sum()),
        "bsc_yes_rows": int(final_df[bsc_output_column].eq("yes").sum()),
        "rows_removed_by_identity_enrichment": 0,
    }

    return final_df, stats
