import pandas as pd


class RemovalLogger:
    OUTPUT_COLUMNS = [
        "Employee Email",
        "Employee Name",
        "Zone",
        "Removal Reason",
        "Removal Stage",
    ]

    def __init__(self):
        self._frames = []

    def log(
        self,
        df,
        reason,
        stage,
        email_column="Employee Email",
        name_column="Employee Name",
        zone_column="Zone",
    ):
        if df is None or df.empty:
            return

        source = df.copy()
        logged = pd.DataFrame(index=source.index)
        logged["Employee Email"] = (
            source[email_column] if email_column in source.columns else ""
        )
        logged["Employee Name"] = (
            source[name_column] if name_column in source.columns else ""
        )
        logged["Zone"] = (
            source[zone_column] if zone_column in source.columns else ""
        )
        logged["Removal Reason"] = reason
        logged["Removal Stage"] = stage
        self._frames.append(logged.reset_index(drop=True))

    def to_dataframe(self):
        if not self._frames:
            return pd.DataFrame(columns=self.OUTPUT_COLUMNS)

        output = pd.concat(self._frames, ignore_index=True)
        output = output[self.OUTPUT_COLUMNS]
        output["Employee Email"] = output["Employee Email"].fillna("")
        output["Employee Name"] = output["Employee Name"].fillna("")
        output["Zone"] = output["Zone"].fillna("")

        # Employee Email is the primary identifier. Keep separate rows only
        # where the same email was removed at different stages/reasons.
        output["__email_key__"] = (
            output["Employee Email"].astype(str).str.strip().str.casefold()
        )
        output = output.drop_duplicates(
            subset=["__email_key__", "Removal Reason", "Removal Stage"],
            keep="first",
        ).drop(columns="__email_key__")

        return output.reset_index(drop=True)
