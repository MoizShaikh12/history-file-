from datetime import datetime
from pathlib import Path

import pandas as pd

from modules.utils import (
    resolve_column,
    normalize_email,
    extract_emails_from_text,
)


def _parse_sheet_date(sheet_name):
    """
    Convert a date-based Excel sheet name into a datetime value.

    Supported examples:
    - 25 May 2026
    - 19 Feb 2026
    - 05/25/2026
    - 2026-05-25
    """

    sheet_name = str(sheet_name).strip()

    date_formats = [
        "%d %b %Y",
        "%d %B %Y",
        "%m/%d/%Y",
        "%Y-%m-%d",
    ]

    for date_format in date_formats:
        try:
            return datetime.strptime(
                sheet_name,
                date_format,
            )
        except ValueError:
            continue

    return None


def _get_latest_date_sheet(excel_file):
    """
    Select the latest dated sheet from the CEO Minus workbook.

    Sheets whose names cannot be interpreted as dates are ignored.
    """

    dated_sheets = []

    for sheet_name in excel_file.sheet_names:
        parsed_date = _parse_sheet_date(sheet_name)

        if parsed_date is not None:
            dated_sheets.append(
                (
                    parsed_date,
                    sheet_name,
                )
            )

    if not dated_sheets:
        raise ValueError(
            "No date-based sheet was found in the CEO Minus file."
        )

    dated_sheets.sort(
        key=lambda item: item[0],
        reverse=True,
    )

    latest_date = dated_sheets[0][0]
    latest_sheet = dated_sheets[0][1]

    return latest_sheet, latest_date


def remove_latest_ceo_managers(
    output_df,
    ceo_file,
    employee_email_column="Employee Email",
):
    """
    Remove users whose Employee Email appears in the Mail ID column
    of the latest dated CEO Minus sheet.

    Important:
    - The matching column is Mail ID.
    - The Manager column is not used.
    - Email matching is case-insensitive.
    - Cells containing multiple emails are supported.
    - Removed rows are returned for the Removed Users Report.

    Returns:
    - filtered_df
    - stats
    - removed_rows
    """

    ceo_file = Path(ceo_file)

    if not ceo_file.exists():
        raise FileNotFoundError(
            f"CEO Minus file not found: {ceo_file}"
        )

    if employee_email_column not in output_df.columns:
        raise KeyError(
            f"Output column '{employee_email_column}' not found."
        )

    excel_file = pd.ExcelFile(
        ceo_file,
        engine="openpyxl",
    )

    latest_sheet, latest_date = _get_latest_date_sheet(
        excel_file
    )

    ceo_df = pd.read_excel(
        ceo_file,
        sheet_name=latest_sheet,
        dtype=object,
        engine="openpyxl",
    )

    mail_id_column = resolve_column(
        ceo_df,
        "Mail ID",
    )

    if mail_id_column is None:
        raise KeyError(
            f"Mail ID column not found in CEO sheet '{latest_sheet}'."
        )

    ceo_mail_ids = set()

    for value in ceo_df[mail_id_column]:
        emails_found = extract_emails_from_text(value)

        if emails_found:
            for email in emails_found:
                normalized_email = normalize_email(email)

                if normalized_email:
                    ceo_mail_ids.add(normalized_email)
        else:
            normalized_email = normalize_email(value)

            if normalized_email and "@" in normalized_email:
                ceo_mail_ids.add(normalized_email)

    output_email_keys = output_df[
        employee_email_column
    ].apply(normalize_email)

    remove_mask = output_email_keys.isin(
        ceo_mail_ids
    )

    removed_rows = output_df.loc[
        remove_mask
    ].copy()

    filtered_df = output_df.loc[
        ~remove_mask
    ].copy()

    stats = {
        "ceo_latest_sheet_used": latest_sheet,
        "ceo_latest_sheet_date": latest_date.strftime(
            "%Y-%m-%d"
        ),
        "ceo_rows_scanned": int(len(ceo_df)),
        "ceo_mapping_column_used": "Mail ID",
        "ceo_mail_id_count_from_latest_sheet": int(
            len(ceo_mail_ids)
        ),
        "rows_before_ceo_mail_id_filter": int(
            len(output_df)
        ),
        "rows_removed_by_ceo_mail_id_filter": int(
            remove_mask.sum()
        ),
        "rows_after_ceo_mail_id_filter": int(
            len(filtered_df)
        ),
    }

    return (
        filtered_df,
        stats,
        removed_rows,
    )