def remove_blank_and_noemail_rows(
    df,
    email_column="Employee Email",
):
    """
    Remove rows where Employee Email is blank or starts with 'noemail'.

    Returns:
    1. cleaned_df
    2. stats
    3. blank_email_rows
    4. noemail_rows
    """

    if email_column not in df.columns:
        raise KeyError(
            f"Required email column '{email_column}' was not found."
        )

    email_clean = (
        df[email_column]
        .fillna("")
        .astype(str)
        .str.strip()
    )

    email_lower = email_clean.str.casefold()

    blank_mask = email_clean.eq("")

    noemail_mask = (
        email_lower.str.startswith("noemail")
        & ~blank_mask
    )

    remove_mask = blank_mask | noemail_mask

    cleaned_df = df.loc[
        ~remove_mask
    ].copy()

    blank_email_rows = df.loc[
        blank_mask
    ].copy()

    noemail_rows = df.loc[
        noemail_mask
    ].copy()

    stats = {
        "original_rows": int(len(df)),
        "blank_email_rows": int(blank_mask.sum()),
        "noemail_rows": int(noemail_mask.sum()),
        "removed_rows": int(remove_mask.sum()),
        "final_rows": int(len(cleaned_df)),
    }

    return (
        cleaned_df,
        stats,
        blank_email_rows,
        noemail_rows,
    )
