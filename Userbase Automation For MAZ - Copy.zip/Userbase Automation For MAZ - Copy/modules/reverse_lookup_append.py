import pandas as pd

from modules.utils import (
    resolve_column,
    normalize_value,
    normalize_email,
)


def _standardize_columns(df, wanted_columns):
    """
    Rename matching source columns to the expected standard names.

    resolve_column() handles differences in capitalization,
    spaces, line breaks, and hidden characters.
    """

    output = df.copy()
    rename_map = {}

    for wanted_column in wanted_columns:
        actual_column = resolve_column(
            output,
            wanted_column,
        )

        if (
            actual_column is not None
            and actual_column != wanted_column
        ):
            rename_map[actual_column] = wanted_column

    if rename_map:
        output = output.rename(
            columns=rename_map
        )

    return output


def append_not_found_reverse_lookup_users(
    output_df,
    aurora_df,
    bsc_df,
    employee_name_column="Employee Name",
    employee_email_column="Employee Email",
    aurora_filter_column="Aurora Users",
    bsc_filter_column="BSC (Yes/No)",
):
    """
    Append Aurora and BSC users.

    AURORA LOGIC:
    - Use only rows where reverse lookup = not found.
    - NAME -> Employee Name
    - E-MAIL -> Employee Email
    - Aurora Users -> yes
    - Everything else remains blank.

    BSC LOGIC:
    - Ignore the BSC reverse lookup value.
    - Compare Email - Primary Work with existing output Employee Email.
    - If the email already exists, do not append it again.
    - If the email does not exist, append it.
    - Email - Primary Work -> Employee Email
    - Zone -> Zone
    - BSC (Yes/No) -> yes
    - Everything else remains blank.
    """

    base_columns = list(output_df.columns)

    if employee_email_column not in base_columns:
        raise KeyError(
            f"Output column '{employee_email_column}' not found."
        )

    if "Zone" not in base_columns:
        raise KeyError(
            "Output column 'Zone' not found."
        )

    # ==============================================================
    # AURORA APPEND LOGIC
    # ==============================================================

    aurora_df = _standardize_columns(
        aurora_df,
        [
            "NAME",
            "E-MAIL",
            "reverse lookup",
        ],
    )

    required_aurora_columns = [
        "NAME",
        "E-MAIL",
        "reverse lookup",
    ]

    for column in required_aurora_columns:
        if column not in aurora_df.columns:
            raise KeyError(
                f"Aurora source column '{column}' not found."
            )

    # Aurora remains based on reverse lookup = not found.
    aurora_not_found = aurora_df.loc[
        aurora_df["reverse lookup"]
        .apply(normalize_value)
        .eq("not found")
    ].copy()

    # Do not append Aurora rows with blank emails.
    aurora_not_found = aurora_not_found.loc[
        aurora_not_found["E-MAIL"]
        .apply(normalize_email)
        .ne("")
    ].copy()

    aurora_rows = pd.DataFrame(
        "",
        index=range(len(aurora_not_found)),
        columns=base_columns,
    )

    if employee_name_column in aurora_rows.columns:
        aurora_rows[employee_name_column] = (
            aurora_not_found["NAME"]
            .fillna("")
            .to_numpy()
        )

    aurora_rows[employee_email_column] = (
        aurora_not_found["E-MAIL"]
        .fillna("")
        .to_numpy()
    )

    if aurora_filter_column in aurora_rows.columns:
        aurora_rows[aurora_filter_column] = "yes"

    # ==============================================================
    # BSC APPEND LOGIC
    # ==============================================================

    bsc_df = _standardize_columns(
        bsc_df,
        [
            "Email - Primary Work",
            "Zone",
        ],
    )

    required_bsc_columns = [
        "Email - Primary Work",
        "Zone",
    ]

    for column in required_bsc_columns:
        if column not in bsc_df.columns:
            raise KeyError(
                f"BSC source column '{column}' not found."
            )

    # Start with every BSC row.
    # reverse lookup is intentionally not used.
    bsc_candidates = bsc_df.copy()

    # Create a normalized BSC email key.
    bsc_candidates["__email_key__"] = (
        bsc_candidates["Email - Primary Work"]
        .apply(normalize_email)
    )

    # Remove BSC rows where Email - Primary Work is blank.
    bsc_candidates = bsc_candidates.loc[
        bsc_candidates["__email_key__"].ne("")
    ].copy()

    # Remove duplicate emails within the BSC source itself.
    # The first BSC occurrence is retained.
    bsc_candidates = bsc_candidates.drop_duplicates(
        subset=["__email_key__"],
        keep="first",
    ).copy()

    # Build the normalized set of emails already present in output.
    existing_output_emails = {
        normalize_email(value)
        for value in output_df[employee_email_column]
        if normalize_email(value)
    }

    # Also include Aurora rows about to be appended, preventing BSC from
    # appending the same email again during the same pipeline run.
    aurora_emails_to_append = {
        normalize_email(value)
        for value in aurora_rows[employee_email_column]
        if normalize_email(value)
    }

    existing_or_aurora_emails = (
        existing_output_emails
        | aurora_emails_to_append
    )

    # Keep only BSC emails that are not already in the output
    # and are not being appended from Aurora.
    bsc_to_append = bsc_candidates.loc[
        ~bsc_candidates["__email_key__"].isin(
            existing_or_aurora_emails
        )
    ].copy()

    # Create blank rows using the final output structure.
    bsc_rows = pd.DataFrame(
        "",
        index=range(len(bsc_to_append)),
        columns=base_columns,
    )

    # Map BSC Email - Primary Work to output Employee Email.
    bsc_rows[employee_email_column] = (
        bsc_to_append["Email - Primary Work"]
        .fillna("")
        .to_numpy()
    )

    # Map the corresponding BSC Zone to output Zone.
    bsc_rows["Zone"] = (
        bsc_to_append["Zone"]
        .fillna("")
        .to_numpy()
    )

    # Mark newly appended rows as BSC users.
    if bsc_filter_column in bsc_rows.columns:
        bsc_rows[bsc_filter_column] = "yes"

    # ==============================================================
    # COMBINE OUTPUT
    # ==============================================================

    combined_df = pd.concat(
        [
            output_df,
            aurora_rows,
            bsc_rows,
        ],
        ignore_index=True,
    )

    stats = {
        "rows_before_reverse_lookup_append": int(
            len(output_df)
        ),
        "aurora_not_found_rows_appended": int(
            len(aurora_rows)
        ),
        "bsc_source_rows_checked": int(
            len(bsc_df)
        ),
        "bsc_rows_with_valid_email": int(
            len(bsc_candidates)
        ),
        "bsc_existing_email_rows_not_appended": int(
            len(bsc_candidates) - len(bsc_to_append)
        ),
        "bsc_new_email_rows_appended": int(
            len(bsc_rows)
        ),
        "total_reverse_lookup_rows_appended": int(
            len(aurora_rows) + len(bsc_rows)
        ),
        "rows_after_reverse_lookup_append": int(
            len(combined_df)
        ),
        "aurora_filter_set_yes_for_appended_rows": int(
            len(aurora_rows)
        ),
        "bsc_filter_set_yes_for_appended_rows": int(
            len(bsc_rows)
        ),
        "bsc_zone_mapped_for_appended_rows": int(
            bsc_rows["Zone"]
            .fillna("")
            .astype(str)
            .str.strip()
            .ne("")
            .sum()
        ),
        "bsc_reverse_lookup_used_for_append": "No",
    }

    return combined_df, stats