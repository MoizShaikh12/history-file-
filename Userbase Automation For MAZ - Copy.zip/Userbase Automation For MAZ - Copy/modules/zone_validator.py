import pandas as pd

from modules.utils import (
    resolve_column,
    normalize_value,
    normalize_id,
    normalize_email,
)


def _standardize_columns(df, wanted_columns):
    """
    Rename matching source columns to the expected standard names.

    The resolve_column helper handles differences in:
    - capitalization
    - spacing
    - line breaks
    - hidden characters
    """
    output = df.copy()
    rename_map = {}

    for wanted_column in wanted_columns:
        actual_column = resolve_column(output, wanted_column)

        if actual_column is not None and actual_column != wanted_column:
            rename_map[actual_column] = wanted_column

    if rename_map:
        output = output.rename(columns=rename_map)

    return output


def _build_key(df, key_columns):
    """
    Build a composite validation key using the configured key columns.

    ID columns use normalize_id.
    Other columns use normalize_value.
    """
    if not key_columns:
        raise ValueError("At least one validation key column is required.")

    key_parts = []

    for column in key_columns:
        if column not in df.columns:
            raise KeyError(
                f"Required key column '{column}' was not found."
            )

        if "id" in column.casefold():
            normalized_part = df[column].apply(normalize_id)
        else:
            normalized_part = df[column].apply(normalize_value)

        key_parts.append(normalized_part)

    composite_key = key_parts[0]

    for part in key_parts[1:]:
        composite_key = composite_key + "|" + part

    return composite_key


def validate_maz_ok_users(
    cleaned_df,
    maz_df,
    key_columns,
    action_column="Action",
    zone_validated_column="Zone Validated",
    validated_value="MAZ Validated",
):
    """
    Apply MAZ validation to the cleaned DataMart.

    Business rules:
    - Keep every non-MAZ user.
    - For Zone = MAZ, keep the user only if the matching record in the
      MAZ validation sheet has Action = OK.
    - Remove MAZ users that are not found or do not have Action = OK.
    - Return the removed MAZ rows for the Removed Users Report.

    Returns:
    - validated_df
    - stats
    - removed_rows
    """
    cleaned_df = _standardize_columns(
        cleaned_df,
        key_columns + ["Zone"],
    )

    maz_df = _standardize_columns(
        maz_df,
        key_columns + [action_column],
    )

    if "Zone" not in cleaned_df.columns:
        raise KeyError(
            "Column 'Zone' was not found in cleaned DataMart output."
        )

    if action_column not in maz_df.columns:
        raise KeyError(
            f"Action column '{action_column}' was not found in MAZ sheet."
        )

    for column in key_columns:
        if column not in cleaned_df.columns:
            raise KeyError(
                f"Column '{column}' was not found in cleaned DataMart output."
            )

        if column not in maz_df.columns:
            raise KeyError(
                f"Column '{column}' was not found in MAZ validation sheet."
            )

    # Only reference records with Action = OK are valid MAZ users.
    maz_ok_df = maz_df.loc[
        maz_df[action_column]
        .apply(normalize_value)
        .eq("ok")
    ].copy()

    maz_ok_keys = set(
        _build_key(
            maz_ok_df,
            key_columns,
        )
    )

    cleaned_keys = _build_key(
        cleaned_df,
        key_columns,
    )

    zone_is_maz_mask = (
        cleaned_df["Zone"]
        .fillna("")
        .astype(str)
        .str.strip()
        .str.upper()
        .eq("MAZ")
    )

    maz_ok_match_mask = cleaned_keys.isin(maz_ok_keys)

    # Keep all non-MAZ rows.
    # Keep MAZ rows only if matched with Action = OK.
    keep_mask = (
        ~zone_is_maz_mask
    ) | (
        zone_is_maz_mask & maz_ok_match_mask
    )

    removed_rows = cleaned_df.loc[
        ~keep_mask
    ].copy()

    validated_df = cleaned_df.loc[
        keep_mask
    ].copy()

    validated_df[zone_validated_column] = ""

    retained_maz_mask = (
        validated_df["Zone"]
        .fillna("")
        .astype(str)
        .str.strip()
        .str.upper()
        .eq("MAZ")
    )

    validated_df.loc[
        retained_maz_mask,
        zone_validated_column,
    ] = validated_value

    stats = {
        "rows_before_maz_validation": int(len(cleaned_df)),
        "maz_sheet_rows": int(len(maz_df)),
        "maz_ok_rows": int(len(maz_ok_df)),
        "non_maz_rows_kept": int((~zone_is_maz_mask).sum()),
        "maz_rows_before_validation": int(zone_is_maz_mask.sum()),
        "maz_rows_kept_action_ok": int(
            (zone_is_maz_mask & maz_ok_match_mask).sum()
        ),
        "maz_rows_removed_not_ok_or_not_found": int(
            (zone_is_maz_mask & ~maz_ok_match_mask).sum()
        ),
        "rows_kept_after_maz_validation": int(len(validated_df)),
        "rows_removed_by_maz_validation": int((~keep_mask).sum()),
        "rows_marked_as_maz_validated": int(
            retained_maz_mask.sum()
        ),
    }

    return validated_df, stats, removed_rows


def append_maz_additional_users(
    base_df,
    additional_df,
    columns_to_map,
    zone_validated_column="Zone Validated",
    additional_value="MAZ Additional",
):
    """
    Append users from the MAZ Additional sheet.

    Business rules:
    - Map available source columns into the output structure.
    - Leave unavailable output columns blank.
    - Set Zone Validated = MAZ Additional.

    Returns:
    - combined_df
    - stats
    """
    base_columns = list(base_df.columns)

    additional_output = pd.DataFrame(
        "",
        index=additional_df.index,
        columns=base_columns,
    )

    for column in base_columns:
        actual_column = resolve_column(
            additional_df,
            column,
        )

        if actual_column is not None:
            additional_output[column] = additional_df[
                actual_column
            ]

    for column in columns_to_map:
        if column not in additional_output.columns:
            continue

        actual_column = resolve_column(
            additional_df,
            column,
        )

        if actual_column is not None:
            additional_output[column] = additional_df[
                actual_column
            ]

    additional_output[zone_validated_column] = additional_value
    additional_output = additional_output[base_columns]

    combined_df = pd.concat(
        [
            base_df,
            additional_output,
        ],
        ignore_index=True,
    )

    stats = {
        "rows_before_additional_append": int(len(base_df)),
        "additional_sheet_rows": int(len(additional_df)),
        "additional_rows_appended": int(len(additional_output)),
        "rows_after_additional_append": int(len(combined_df)),
    }

    return combined_df, stats


def enforce_maz_action_ok_for_maz_zone(
    output_df,
    maz_df,
    key_columns,
    action_column="Action",
    zone_column="Zone",
    employee_email_column="Employee Email",
    zone_validated_column="Zone Validated",
    maz_additional_value="MAZ Additional",
    validated_value="MAZ Validated",
    bsc_filter_column="BSC (Yes/No)",
):
    """
    Final MAZ enforcement after Aurora and BSC users are appended.

    Rules:
    - Keep all non-MAZ users.
    - Keep all MAZ Additional users.
    - Keep all BSC users, including BSC users whose Zone is MAZ.
    - BSC users do not require Action = OK.
    - Other MAZ users are kept only when they match a MAZ reference
      record where Action = OK.
    - Return removed users for the Removed Users Report.
    """

    output_df = _standardize_columns(
        output_df,
        key_columns
        + [
            zone_column,
            employee_email_column,
            zone_validated_column,
            bsc_filter_column,
        ],
    )

    maz_df = _standardize_columns(
        maz_df,
        key_columns
        + [
            action_column,
            employee_email_column,
        ],
    )

    if zone_column not in output_df.columns:
        raise KeyError(
            f"Column '{zone_column}' was not found in output."
        )

    if employee_email_column not in output_df.columns:
        raise KeyError(
            f"Column '{employee_email_column}' was not found in output."
        )

    if action_column not in maz_df.columns:
        raise KeyError(
            f"Column '{action_column}' was not found in MAZ sheet."
        )

    for column in key_columns:
        if column not in output_df.columns:
            raise KeyError(
                f"Validation column '{column}' was not found in output."
            )

        if column not in maz_df.columns:
            raise KeyError(
                f"Validation column '{column}' was not found in MAZ sheet."
            )

    # Use only MAZ reference records where Action = OK.
    maz_ok_df = maz_df.loc[
        maz_df[action_column]
        .apply(normalize_value)
        .eq("ok")
    ].copy()

    # Match using employee IDs and employee name.
    maz_ok_keys = set(
        _build_key(
            maz_ok_df,
            key_columns,
        )
    )

    output_keys = _build_key(
        output_df,
        key_columns,
    )

    key_match_mask = output_keys.isin(
        maz_ok_keys
    )

    # Also match using Employee Email when available in the MAZ data.
    email_match_mask = pd.Series(
        False,
        index=output_df.index,
        dtype=bool,
    )

    if employee_email_column in maz_ok_df.columns:
        maz_ok_emails = {
            normalize_email(value)
            for value in maz_ok_df[employee_email_column]
            if normalize_email(value)
        }

        output_email_keys = output_df[
            employee_email_column
        ].apply(normalize_email)

        email_match_mask = output_email_keys.isin(
            maz_ok_emails
        )

    # Identify users whose Zone is MAZ.
    zone_is_maz_mask = (
        output_df[zone_column]
        .fillna("")
        .astype(str)
        .str.strip()
        .str.upper()
        .eq("MAZ")
    )

    # Identify MAZ Additional users.
    maz_additional_mask = pd.Series(
        False,
        index=output_df.index,
        dtype=bool,
    )

    if zone_validated_column in output_df.columns:
        maz_additional_mask = (
            output_df[zone_validated_column]
            .fillna("")
            .astype(str)
            .str.strip()
            .str.casefold()
            .eq(maz_additional_value.casefold())
        )

    # Identify BSC users.
    # BSC users bypass final MAZ validation.
    bsc_user_mask = pd.Series(
        False,
        index=output_df.index,
        dtype=bool,
    )

    if bsc_filter_column in output_df.columns:
        bsc_user_mask = (
            output_df[bsc_filter_column]
            .fillna("")
            .astype(str)
            .str.strip()
            .str.casefold()
            .isin(
                {
                    "yes",
                    "y",
                    "true",
                    "1",
                }
            )
        )

    maz_ok_match_mask = (
        key_match_mask
        | email_match_mask
    )

    # Keep:
    # - All non-MAZ users
    # - All MAZ Additional users
    # - All BSC users
    # - Other MAZ users only when Action = OK
    keep_mask = (
        (~zone_is_maz_mask)
        | maz_additional_mask
        | bsc_user_mask
        | (
            zone_is_maz_mask
            & maz_ok_match_mask
        )
    )

    removed_rows = output_df.loc[
        ~keep_mask
    ].copy()

    filtered_df = output_df.loc[
        keep_mask
    ].copy()

    # Identify retained MAZ users.
    retained_maz_mask = (
        filtered_df[zone_column]
        .fillna("")
        .astype(str)
        .str.strip()
        .str.upper()
        .eq("MAZ")
    )

    # Identify retained MAZ Additional users.
    retained_additional_mask = (
        filtered_df[zone_validated_column]
        .fillna("")
        .astype(str)
        .str.strip()
        .str.casefold()
        .eq(maz_additional_value.casefold())
    )

    # Identify retained BSC users.
    retained_bsc_mask = pd.Series(
        False,
        index=filtered_df.index,
        dtype=bool,
    )

    if bsc_filter_column in filtered_df.columns:
        retained_bsc_mask = (
            filtered_df[bsc_filter_column]
            .fillna("")
            .astype(str)
            .str.strip()
            .str.casefold()
            .isin(
                {
                    "yes",
                    "y",
                    "true",
                    "1",
                }
            )
        )

    # Only regular Action=OK MAZ users receive MAZ Validated.
    # BSC users are not changed to MAZ Validated.
    filtered_df.loc[
        retained_maz_mask
        & ~retained_additional_mask
        & ~retained_bsc_mask,
        zone_validated_column,
    ] = validated_value

    stats = {
        "rows_before_final_maz_enforcement": int(
            len(output_df)
        ),
        "maz_rows_before_final_enforcement": int(
            zone_is_maz_mask.sum()
        ),
        "maz_action_ok_rows_kept": int(
            (
                zone_is_maz_mask
                & maz_ok_match_mask
                & ~bsc_user_mask
            ).sum()
        ),
        "maz_additional_rows_kept": int(
            maz_additional_mask.sum()
        ),
        "bsc_rows_exempted_from_maz_validation": int(
            bsc_user_mask.sum()
        ),
        "bsc_maz_rows_exempted_from_maz_validation": int(
            (
                bsc_user_mask
                & zone_is_maz_mask
            ).sum()
        ),
        "maz_rows_removed_not_ok_or_not_found": int(
            (
                zone_is_maz_mask
                & ~maz_ok_match_mask
                & ~maz_additional_mask
                & ~bsc_user_mask
            ).sum()
        ),
        "rows_after_final_maz_enforcement": int(
            len(filtered_df)
        ),
    }

    return (
        filtered_df,
        stats,
        removed_rows,
    )