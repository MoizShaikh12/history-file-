def remove_duplicate_emails(
    df,
    email_column="Employee Email",
):
    """
    Remove duplicate Employee Email rows.

    Rules:
    - Email comparison is case-insensitive.
    - Leading and trailing spaces are ignored.
    - The first occurrence of each email is retained.
    - Blank emails are not treated as duplicates.
    - Removed duplicate rows are returned for the Removed Users Report.

    Returns:
    - deduped_df
    - stats
    - removed_duplicate_rows
    """

    if email_column not in df.columns:
        raise KeyError(
            f"Required email column '{email_column}' was not found for dedupe."
        )

    work_df = df.copy()

    work_df["__email_key__"] = (
        work_df[email_column]
        .fillna("")
        .astype(str)
        .str.strip()
        .str.casefold()
    )

    duplicate_mask = (
        work_df["__email_key__"].ne("")
        & work_df.duplicated(
            subset=["__email_key__"],
            keep="first",
        )
    )

    removed_duplicate_rows = work_df.loc[
        duplicate_mask
    ].copy()

    deduped_df = work_df.loc[
        ~duplicate_mask
    ].copy()

    removed_duplicate_rows = removed_duplicate_rows.drop(
        columns=["__email_key__"],
        errors="ignore",
    )

    deduped_df = deduped_df.drop(
        columns=["__email_key__"],
        errors="ignore",
    ).reset_index(drop=True)

    stats = {
        "rows_before_email_dedupe": int(len(df)),
        "duplicate_email_rows_removed": int(duplicate_mask.sum()),
        "rows_after_email_dedupe": int(len(deduped_df)),
    }

    return (
        deduped_df,
        stats,
        removed_duplicate_rows,
    )
