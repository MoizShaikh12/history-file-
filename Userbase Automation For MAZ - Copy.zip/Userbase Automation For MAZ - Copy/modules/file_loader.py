from pathlib import Path
import pandas as pd
from openpyxl import load_workbook


def read_excel(file_path, sheet_name=None):
    file_path = Path(file_path)

    if not file_path.exists():
        raise FileNotFoundError(f"Excel file not found: {file_path}")

    if sheet_name is None:
        excel_file = pd.ExcelFile(file_path, engine="openpyxl")
        sheet_name = excel_file.sheet_names[0]

    return pd.read_excel(
        file_path,
        sheet_name=sheet_name,
        dtype=object,
        engine="openpyxl",
    )


def write_excel_with_autofilter(df, output_file, sheet_name="Final Output"):
    output_file = Path(output_file)
    output_file.parent.mkdir(parents=True, exist_ok=True)

    with pd.ExcelWriter(output_file, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name=sheet_name)

    wb = load_workbook(output_file)
    ws = wb[sheet_name]

    if ws.max_row >= 1 and ws.max_column >= 1:
        ws.auto_filter.ref = ws.dimensions
        ws.freeze_panes = "A2"

    wb.save(output_file)
