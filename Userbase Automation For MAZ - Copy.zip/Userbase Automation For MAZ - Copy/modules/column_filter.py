import pandas as pd
from modules.utils import resolve_column


def filter_required_columns(datamart_df, required_columns):
    found_columns = []
    missing_columns = []
    output_df = pd.DataFrame(index=datamart_df.index)

    for required_col in required_columns:
        actual_col = resolve_column(datamart_df, required_col)

        if actual_col is not None:
            output_df[required_col] = datamart_df[actual_col]
            found_columns.append(required_col)
        else:
            missing_columns.append(required_col)

    return output_df, found_columns, missing_columns
