from pathlib import Path
import pandas as pd


def _dict_to_df(stats):
    return pd.DataFrame([{"Metric": k, "Value": v} for k, v in stats.items()])


def build_report_sheets(
    original_datamart_rows,
    selected_rows,
    found_columns,
    missing_columns,
    email_stats,
    validation_stats,
    additional_stats,
    dedupe_stats,
    ot_stats,
    identity_stats=None,
    reverse_lookup_stats=None,
    ceo_filter_stats=None,
):
    identity_stats = identity_stats or {}
    reverse_lookup_stats = reverse_lookup_stats or {}
    ceo_filter_stats = ceo_filter_stats or {}

    summary = {
        "original_datamart_rows": int(original_datamart_rows),
        "rows_after_column_selection": int(selected_rows),
        "found_required_columns": int(len(found_columns)),
        "missing_required_columns": int(len(missing_columns)),
        "rows_after_email_cleaning": int(email_stats.get("final_rows", 0)),
        "rows_after_maz_validation": int(validation_stats.get("rows_kept_after_maz_validation", 0)),
        "rows_after_additional_append": int(additional_stats.get("rows_after_additional_append", 0)),
        "rows_after_email_dedupe": int(dedupe_stats.get("rows_after_email_dedupe", 0)),
        "final_rows_after_ot_column": int(ot_stats.get("rows_after_ot_column", 0)),
        "final_rows_after_identity_enrichment": int(identity_stats.get("rows_after_identity_enrichment", 0)),
        "rows_after_reverse_lookup_append": int(reverse_lookup_stats.get("rows_after_reverse_lookup_append", 0)),
        "rows_removed_by_ceo_manager_filter": int(ceo_filter_stats.get("rows_removed_by_ceo_manager_filter", 0)),
        "final_rows_after_ceo_manager_filter": int(ceo_filter_stats.get("rows_after_ceo_manager_filter", 0)),
    }

    column_rows = [{"Column": c, "Status": "Found in DataMart and included"} for c in found_columns]
    column_rows += [{"Column": c, "Status": "Missing in DataMart and excluded"} for c in missing_columns]

    report_sheets = {
        "Summary": _dict_to_df(summary),
        "Column Check": pd.DataFrame(column_rows),
        "Email Cleaning": _dict_to_df(email_stats),
        "MAZ Validation": _dict_to_df(validation_stats),
        "MAZ Additional": _dict_to_df(additional_stats),
        "Email Dedupe": _dict_to_df(dedupe_stats),
        "OT Column": _dict_to_df(ot_stats),
    }

    if identity_stats:
        report_sheets["Identity Enrichment"] = _dict_to_df(identity_stats)

    if reverse_lookup_stats:
        report_sheets["Reverse Lookup Append"] = _dict_to_df(reverse_lookup_stats)

    if ceo_filter_stats:
        report_sheets["CEO Manager Filter"] = _dict_to_df(ceo_filter_stats)

    return report_sheets


def write_report(report_sheets, output_file):
    output_file = Path(output_file)
    output_file.parent.mkdir(parents=True, exist_ok=True)

    with pd.ExcelWriter(output_file, engine="openpyxl") as writer:
        for sheet_name, df in report_sheets.items():
            df.to_excel(writer, index=False, sheet_name=sheet_name[:31])
