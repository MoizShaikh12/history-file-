# DataMart Userbase Full Automation - V2

This is the complete ready-to-paste automation folder.

## Input files required

Place the following files inside the `input` folder:

```text
DataMart.xlsx
MAZ zone data.xlsx
Saviynt.xlsx
O365.xlsx
Aurora Users.xlsx
BSC users.xlsx
CEO Minus 1 and 2 - 2026 1.xlsx
```

## Run

Open PowerShell in this project folder and run:

```powershell
python main.py
```

## Pipeline

1. Load DataMart.
2. Keep only required DataMart columns.
3. Remove rows with blank Employee Email or emails starting with `noemail`.
4. Validate MAZ users using `MAZ zone data.xlsx`, sheet `MAZ`, column `Action = OK`.
   - This only marks users as `MAZ Validated`.
   - It does not delete unmatched users.
5. Append users from `MAZ zone data.xlsx`, sheet `add to the list`, as `MAZ Additional`.
6. Remove duplicate `Employee Email` rows.
7. Add `OT Filter` column as `Yes` or `No`.
8. Add identity/userbase enrichment columns:
   - `SSOUPN as per Saviynt`
   - `SSOUPN as per AD (O365)`
   - `Aurora Users`
   - `BSC (Yes/No)`
9. Append reverse lookup not-found rows:
   - From `Aurora Users.xlsx`, sheet `Aurora Userbase`, where `reverse lookup = not found`:
     - `NAME` -> `Employee Name`
     - `E-MAIL` -> `Employee Email`
     - all other columns blank
   - From `BSC users.xlsx`, sheet `main`, where `reverse lookup = not found`:
     - `Email - Primary Work` -> `Employee Email`
     - all other columns blank
10. CEO Manager exclusion:
   - Reads `CEO Minus 1 and 2 - 2026 1.xlsx`.
   - Automatically selects latest dated sheet, e.g. `25 May 2026` over `19 Feb 2026`.
   - Removes rows where Employee Email is present in the latest sheet's `Manager` column.
11. Export final file and report.

All email matching is case-insensitive and trims leading/trailing spaces.
