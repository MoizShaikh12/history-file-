from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
INPUT_DIR = BASE_DIR / "input"
OUTPUT_DIR = BASE_DIR / "output"

# Main input files
DEFAULT_DATAMART_FILE = INPUT_DIR / "Data Mart for userbase creation.xlsx"
DEFAULT_MAZ_ZONE_FILE = INPUT_DIR / "MAZ zone data.xlsx"

# Reference files for identity/userbase enrichment
DEFAULT_SAVIYNT_FILE = INPUT_DIR / "Saviynt.xlsx"
DEFAULT_O365_FILE = INPUT_DIR / "O365.xlsx"
DEFAULT_AURORA_FILE = INPUT_DIR / "Aurora Users.xlsx"
DEFAULT_BSC_FILE = INPUT_DIR / "BSC users.xlsx"
DEFAULT_CEO_FILE = INPUT_DIR / "CEO Minus 1 and 2 - 2026 1.xlsx"

# Sheet names
DATAMART_SHEET = None                 # None = first sheet
MAZ_VALIDATION_SHEET = "MAZ"
MAZ_ADDITIONAL_SHEET = "add to the list"
SAVIYNT_SHEET = None                  # None = first sheet
O365_SHEET = "Export"
AURORA_SHEET = "Aurora Userbase"
BSC_SHEET = "main"

# Core columns
EMAIL_COLUMN = "Employee Email"
ZONE_VALIDATED_COLUMN = "Zone Validated"
OT_FILTER_COLUMN = "OT Filter"

# Final enrichment output columns
SAVIYNT_OUTPUT_COLUMN = "SSOUPN as per Saviynt"
O365_OUTPUT_COLUMN = "SSOUPN as per AD (O365)"
AURORA_OUTPUT_COLUMN = "Aurora Users"
BSC_OUTPUT_COLUMN = "BSC (Yes/No)"

# Step 1 required DataMart columns
REQUIRED_COLUMNS = [
    "Zone",
    "Country",
    "Global Employee ID",
    "Local Employee ID",
    "Employee Name",
    "Employee Status",
    "Worker Type",
    "Employee Group",
    "Management Level",
    "First Hire Date",
    "Last Hire Date",
    "Position Name",
    "Job Family Group",
    "Job Family",
    "Job Profile Description",
    "ABI Entity 2",
    "Macro Entity Level 2 (Zone)",
    "text before Email",
    "Employee Email",
]

# MAZ validation matching columns
VALIDATION_KEY_COLUMNS = [
    "Global Employee ID",
    "Local Employee ID",
    "Employee Name",
]

# Columns to map from MAZ zone data -> add to the list
ADDITIONAL_COLUMNS_TO_MAP = [
    "Zone",
    "Country",
    "Global Employee ID",
    "Local Employee ID",
    "Employee Name",
    "Employee Status",
    "Management Level",
    "First Hire Date",
    "Last Hire Date",
    "Position Name",
    "Employee Email",
]

# OT Yes/No logic lists
OT_JOB_FAMILY_GROUP_ALLOWED = ["SUPPLY"]

OT_JOB_FAMILY_ALLOWED = [
    "Engineering & Maintenance",
    "Plant Management",
]

OT_JOB_PROFILE_DESCRIPTION_ALLOWED = [
    "Automation Engineer I",
    "Automation Engineer II",
    "Automation Engineer III",
    "Automation Technician I",
    "Automation Technician II",
    "Brewery Plant Director I",
    "Brewery Plant Manager",
    "Electrical I",
    "Electrical II",
    "Engineering & Maintenance Manager I",
    "Engineering & Maintenance Manager II",
    "Engineering & Maintenance Specialist I",
    "Engineering & Maintenance Specialist II",
    "Engineering & Maintenance Specialist III",
    "Engineering & Maintenance Supervisor I",
    "Engineering & Maintenance Supervisor II",
    "Instrumentation Technician I",
    "Instrumentation Technician II",
    "Maintenance Auxiliary I",
    "Maintenance Engineer I",
    "Maintenance Engineer II",
    "Maintenance Engineer III",
    "Maintenance Technician I",
    "Maintenance Technician II",
    "Maintenance Technician III",
    "Maintenance Technician IV",
    "Malting Plant Manager",
    "Mechanical I",
    "Mechanical II",
    "SoftDrinks Plant Manager",
    "Vertical Plant Manager",
]
