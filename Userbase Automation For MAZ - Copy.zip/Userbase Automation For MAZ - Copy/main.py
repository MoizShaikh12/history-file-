from datetime import datetime
from pathlib import Path
from datetime import datetime
from pathlib import Path
import argparse

from config import (
    DEFAULT_DATAMART_FILE,
    DEFAULT_MAZ_ZONE_FILE,
    DEFAULT_SAVIYNT_FILE,
    DEFAULT_O365_FILE,
    DEFAULT_AURORA_FILE,
    DEFAULT_BSC_FILE,
    DEFAULT_CEO_FILE,
    DATAMART_SHEET,
    MAZ_VALIDATION_SHEET,
    MAZ_ADDITIONAL_SHEET,
    SAVIYNT_SHEET,
    O365_SHEET,
    AURORA_SHEET,
    BSC_SHEET,
    OUTPUT_DIR,
    REQUIRED_COLUMNS,
    EMAIL_COLUMN,
    VALIDATION_KEY_COLUMNS,
    ADDITIONAL_COLUMNS_TO_MAP,
    ZONE_VALIDATED_COLUMN,
    OT_FILTER_COLUMN,
    SAVIYNT_OUTPUT_COLUMN,
    O365_OUTPUT_COLUMN,
    AURORA_OUTPUT_COLUMN,
    BSC_OUTPUT_COLUMN,
    OT_JOB_FAMILY_GROUP_ALLOWED,
    OT_JOB_FAMILY_ALLOWED,
    OT_JOB_PROFILE_DESCRIPTION_ALLOWED,
)

from modules.file_loader import read_excel, write_excel_with_autofilter
from modules.column_filter import filter_required_columns
from modules.email_cleaner import remove_blank_and_noemail_rows
from modules.zone_validator import (
    validate_maz_ok_users,
    append_maz_additional_users,
    enforce_maz_action_ok_for_maz_zone,
)
from modules.deduplicator import remove_duplicate_emails
from modules.ot_filter import add_ot_filter_column
from modules.identity_enrichment import enrich_with_identity_sources
from modules.reverse_lookup_append import append_not_found_reverse_lookup_users
from modules.ceo_manager_filter import remove_latest_ceo_managers
from modules.report_generator import build_report_sheets, write_report
from modules.removal_logger import RemovalLogger


def parse_args():
    parser = argparse.ArgumentParser(
        description=(
            "DataMart automation with MAZ validation, identity enrichment, "
            "reverse-lookup append, CEO Mail ID exclusion, and removal reporting."
        )
    )
    parser.add_argument("--datamart", type=Path, default=DEFAULT_DATAMART_FILE)
    parser.add_argument("--maz-zone", type=Path, default=DEFAULT_MAZ_ZONE_FILE)
    parser.add_argument("--saviynt", type=Path, default=DEFAULT_SAVIYNT_FILE)
    parser.add_argument("--o365", type=Path, default=DEFAULT_O365_FILE)
    parser.add_argument("--aurora", type=Path, default=DEFAULT_AURORA_FILE)
    parser.add_argument("--bsc", type=Path, default=DEFAULT_BSC_FILE)
    parser.add_argument("--ceo", type=Path, default=DEFAULT_CEO_FILE)
    parser.add_argument("--output", type=Path, default=None)
    return parser.parse_args()


def main():
    print(f"Running main.py from: {Path(__file__).resolve()}")

    args = parse_args()
    removal_logger = RemovalLogger()

    print("\n====================================================================")
    print(" DATAMART USERBASE FULL AUTOMATION")
    print("====================================================================\n")

    # STEP 1 - Load DataMart and keep required columns.
    datamart_df = read_excel(args.datamart, sheet_name=DATAMART_SHEET)
    selected_df, found_columns, missing_columns = filter_required_columns(
        datamart_df=datamart_df,
        required_columns=REQUIRED_COLUMNS,
    )

    # STEP 2 - Remove blank and noemail records.
    (
        email_cleaned_df,
        email_stats,
        blank_email_rows,
        noemail_rows,
    ) = remove_blank_and_noemail_rows(
        df=selected_df,
        email_column=EMAIL_COLUMN,
    )

    removal_logger.log(
        blank_email_rows,
        reason="Blank Employee Email",
        stage="Email Cleaning",
    )
    removal_logger.log(
        noemail_rows,
        reason="Employee Email starts with noemail",
        stage="Email Cleaning",
    )

    # STEP 3 - Keep non-MAZ users; keep MAZ users only when Action = OK.
    maz_df = read_excel(args.maz_zone, sheet_name=MAZ_VALIDATION_SHEET)

    (
        maz_validated_df,
        validation_stats,
        removed_maz_rows,
    ) = validate_maz_ok_users(
        cleaned_df=email_cleaned_df,
        maz_df=maz_df,
        key_columns=VALIDATION_KEY_COLUMNS,
        action_column="Action",
        zone_validated_column=ZONE_VALIDATED_COLUMN,
        validated_value="MAZ Validated",
    )

    removal_logger.log(
        removed_maz_rows,
        reason="Zone is MAZ but user is not found with Action = OK",
        stage="MAZ Validation",
    )

    # STEP 4 - Append MAZ Additional users.
    additional_df = read_excel(args.maz_zone, sheet_name=MAZ_ADDITIONAL_SHEET)

    combined_df, additional_stats = append_maz_additional_users(
        base_df=maz_validated_df,
        additional_df=additional_df,
        columns_to_map=ADDITIONAL_COLUMNS_TO_MAP,
        zone_validated_column=ZONE_VALIDATED_COLUMN,
        additional_value="MAZ Additional",
    )

    # STEP 5 - Remove duplicate Employee Email rows.
    (
        deduped_df,
        dedupe_stats,
        removed_duplicate_rows,
    ) = remove_duplicate_emails(
        df=combined_df,
        email_column=EMAIL_COLUMN,
    )

    removal_logger.log(
        removed_duplicate_rows,
        reason="Duplicate Employee Email; first occurrence retained",
        stage="Email Dedupe",
    )

    # STEP 6 - Add OT Filter Yes/No without removing rows.
    ot_df, ot_stats = add_ot_filter_column(
        df=deduped_df,
        job_family_group_allowed=OT_JOB_FAMILY_GROUP_ALLOWED,
        job_family_allowed=OT_JOB_FAMILY_ALLOWED,
        job_profile_allowed=OT_JOB_PROFILE_DESCRIPTION_ALLOWED,
        ot_filter_column=OT_FILTER_COLUMN,
    )

    # STEP 7 - Load reference files.
    saviynt_df = read_excel(args.saviynt, sheet_name=SAVIYNT_SHEET)
    o365_df = read_excel(args.o365, sheet_name=O365_SHEET)
    aurora_df = read_excel(args.aurora, sheet_name=AURORA_SHEET)
    bsc_df = read_excel(args.bsc, sheet_name=BSC_SHEET)

    # STEP 8 - Add Saviynt, O365, Aurora, and BSC columns.
    enriched_df, identity_stats = enrich_with_identity_sources(
        output_df=ot_df,
        employee_email_column=EMAIL_COLUMN,
        saviynt_df=saviynt_df,
        o365_df=o365_df,
        aurora_df=aurora_df,
        bsc_df=bsc_df,
        saviynt_output_column=SAVIYNT_OUTPUT_COLUMN,
        o365_output_column=O365_OUTPUT_COLUMN,
        aurora_output_column=AURORA_OUTPUT_COLUMN,
        bsc_output_column=BSC_OUTPUT_COLUMN,
    )

    # STEP 9 - Append Aurora/BSC reverse-lookup not-found rows.
    reverse_appended_df, reverse_lookup_stats = append_not_found_reverse_lookup_users(
        output_df=enriched_df,
        aurora_df=aurora_df,
        bsc_df=bsc_df,
        employee_name_column="Employee Name",
        employee_email_column=EMAIL_COLUMN,
        aurora_filter_column=AURORA_OUTPUT_COLUMN,
        bsc_filter_column=BSC_OUTPUT_COLUMN,
    )

    # STEP 10 - Re-enforce MAZ rule after Aurora/BSC appends.
    (
        maz_enforced_df,
        final_maz_enforcement_stats,
        removed_final_maz_rows,
    ) = enforce_maz_action_ok_for_maz_zone(
        output_df=reverse_appended_df,
        maz_df=maz_df,
        key_columns=VALIDATION_KEY_COLUMNS,
        action_column="Action",
        zone_column="Zone",
        employee_email_column=EMAIL_COLUMN,
        zone_validated_column=ZONE_VALIDATED_COLUMN,
        maz_additional_value="MAZ Additional",
        validated_value="MAZ Validated",
    )

    removal_logger.log(
        removed_final_maz_rows,
        reason="Appended MAZ user is not found with Action = OK",
        stage="Final MAZ Enforcement",
    )

    # STEP 11 - Remove users found in Mail ID of latest dated CEO sheet.
    (
        final_df,
        ceo_filter_stats,
        removed_ceo_rows,
    ) = remove_latest_ceo_managers(
        output_df=maz_enforced_df,
        ceo_file=args.ceo,
        employee_email_column=EMAIL_COLUMN,
    )

    removal_logger.log(
        removed_ceo_rows,
        reason="Employee Email found in CEO latest-sheet Mail ID",
        stage="CEO Mail ID Filter",
    )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    output_file = (
        args.output.resolve()
        if args.output
        else (
            OUTPUT_DIR
            / f"Final_Userbase_With_Identity_Enrichment_{timestamp}.xlsx"
        ).resolve()
    )
    report_file = (
        OUTPUT_DIR / f"Automation_Report_{timestamp}.xlsx"
    ).resolve()
    removed_users_file = (
        OUTPUT_DIR / f"Removed_Users_Report_{timestamp}.xlsx"
    ).resolve()

    write_excel_with_autofilter(
        final_df,
        output_file,
        sheet_name="Final Output",
    )

    removed_users_df = removal_logger.to_dataframe()

    required_removed_columns = [
        "Employee Email",
        "Employee Name",
        "Zone",
        "Removal Reason",
        "Removal Stage",
    ]
    for column in required_removed_columns:
        if column not in removed_users_df.columns:
            removed_users_df[column] = ""
    removed_users_df = removed_users_df[required_removed_columns]

    print(f"Writing removed-users report to: {removed_users_file}")
    write_excel_with_autofilter(
        removed_users_df,
        removed_users_file,
        sheet_name="Removed Users",
    )

    if not removed_users_file.exists():
        raise RuntimeError(
            f"Removed-users report was not created: {removed_users_file}"
        )

    report_sheets = build_report_sheets(
        original_datamart_rows=len(datamart_df),
        selected_rows=len(selected_df),
        found_columns=found_columns,
        missing_columns=missing_columns,
        email_stats=email_stats,
        validation_stats=validation_stats,
        additional_stats=additional_stats,
        dedupe_stats=dedupe_stats,
        ot_stats=ot_stats,
        identity_stats=identity_stats,
        reverse_lookup_stats=reverse_lookup_stats,
        ceo_filter_stats=ceo_filter_stats,
    )
    write_report(report_sheets, report_file)

    print("Automation completed successfully.")
    print(f"Final output file   : {output_file}")
    print(f"Report file         : {report_file}")
    print(f"Removed users file  : {removed_users_file}")
    print(f"Final rows          : {len(final_df):,}")
    print(f"Removed log entries : {len(removed_users_df):,}")
    print(f"Final columns       : {len(final_df.columns):,}")

    print("\nFinal MAZ enforcement summary:")
    for key, value in final_maz_enforcement_stats.items():
        print(f" - {key}: {value}")

    if missing_columns:
        print("\nMissing columns not found in DataMart:")
        for column in missing_columns:
            print(f" - {column}")


if __name__ == "__main__":
    main()
